import React, { useState } from "react";

function Checkout() {
  const [inputValue, setInputValue] = useState("");
  const [result, setResult] = useState(0);
  const [error, setError] = useState("");

  // Handle input change
  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(""); // Reset any previous errors
    setResult(0);

    try {
      const response = await fetch("http://localhost:5007/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(inputValue),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }

      const data = await response.json();
      setResult(data); // Assuming the API returns some data
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="rules-checker">
      <form onSubmit={handleSubmit}>
        <label>Enter Products :</label>
        <input type="text" value={inputValue} onChange={handleInputChange} />
        <button disabled="false" type="submit">
          Submit
        </button>
      </form>

      <div className="result-block">
        {!error && <div>Total : {JSON.stringify(result)}</div>}

        {error && <div className="error">Error : {error}</div>}
      </div>
    </div>
  );
}

export default Checkout;

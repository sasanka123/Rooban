export default function Header() {
  return (
    <header>
      <img src="./logo.png" alt="" srcset="" />
      <h2>Checkout App</h2>
    </header>
  );
}
